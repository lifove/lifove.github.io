Directories:
NoN: TCA without any normalization
N1: TCA with N1
N2: TCA with N2
N3: TCA with N3
N4: TCA with N4
Original: Original data set without applying any trafer learning algorithms
SimVectors: Similarity vectors for TCA+

