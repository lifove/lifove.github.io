Values of Similarity vectors are mapped as follows:
3: MUCH MORE
2: MORE
1: SLIGHTLY MORE
0: SAME
-1: SLIGHTLY LESS
-2: LESS
-3: MUCH LESS
